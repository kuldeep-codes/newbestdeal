# Java-Codes
Java Practice Codes
