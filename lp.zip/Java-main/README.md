# Java
Java Codes: DU Practical List
